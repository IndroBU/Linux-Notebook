
cd "data/"
echo "Enter one of the following actions or press CTRL-D to exit";
echo "C-Create a new note"
echo "R-Read/Search an existing note"
echo "U-upadate an existing note"
echo "D-Delete an existing note"
echo "S-Show All Notes title"
echo "Q-Quit the notebook"
echo -n "Enter your menu choice: "

while : 
do

read choice
choice=${choice^^}

case $choice  in
  #Case1
  C)  
       
          echo -n "Plase,Type without whitespace : "
                     read filename
         
       filename=${filename,,}
   
	  filename=$filename
	  temp_filename=$filename.txt
       if [ -f "$temp_filename" ];
	then
	
		echo "This title name already exists. Try to create with different title"
		echo "The following titles match with your new titles: "

               ls -f | grep $filename
               echo -n "Create new notes:  "
                     read filename
               
            filename=${filename,,}
   
	      filename=$filename
		
	   touch "$filename.txt"
                echo "$filename.txt is successfully created"
                echo "Write your Notes"
                cat >  "$filename.txt"
        else 
                touch "$filename.txt"
                echo "$filename.txt is successfully created"
                echo "Write your Notes"
                cat >  "$filename.txt"
           
           
               
        fi
        
      
        ;;
          
  #Case 2
  R)  
      
     echo -n "Please,Type without whitespace: "
     read item_name
     filename=${item_name,,} 
     
     echo "Your notes may be found here"
     ls -f | grep $filename
     
     echo "Please,Type an existing title which one you want to read: "
     read filename
     filename=${filename,,} 
     
     filename=$filename.txt
     if [ -f "$filename" ];
     then 
        
        cat $filename
        
     else "File not Found"
     fi 
 
         
     
   
         ;;
         
  #Case 3
  U)  
  
  echo -n "Please,Type without whitespace: "
     read item_name
     filename=${item_name,,} 
     
     echo "Your notes may be found here"
     ls -f | grep $filename
      echo "After Editing press ctrl+s, ctrl+o, ctrl+c, ctrl+x"
     echo "Please,Type an existing title which one you want to update: "
     
     read filename
     filename=${filename,,} 
     
       temp_filename=$filename.txt
       if [ -f "$temp_filename" ];
          then

          
              #gedit "$filename.txt"
            
             
           nano "$filename.txt"
           
               echo "$filename.txt is successfully updated"
          
          
       else
          echo "File not found"
        fi
    
     
      ;;
  
  
  

              
  # Case 4
  D)  
   echo -n "Please,Type without whitespace: "
     read item_name
     filename=${item_name,,} 
     
     echo "Your notes may be found here"
     ls -f | grep $filename
     
     echo "Please,Type an existing title which one you want to delete: "
     read filename
     filename=${filename,,} 
     
       temp_filename=$filename.txt
       if [ -f "$temp_filename" ];
          then
          rm $filename.txt
          
          
       else
          echo "File not found"
        fi
    
     
      ;;
    #Case 5
    S)
        echo "Your current notes are: "
        ls  
     
        ;;
    Q)
       exit
       ;; 
      
  *) 
    exit;;
esac
  echo -n "Enter your menu choice: "
done

